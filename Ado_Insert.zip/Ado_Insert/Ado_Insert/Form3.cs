﻿using Ado_Insert.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_Insert
{
    public partial class Form3 : Form
    {
        CourseLogic ob;

        public Form3()
        {
            InitializeComponent();
            ob = new CourseLogic();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;
            TBCNAME.Visible = false;
            TBCAT.Visible = false;
            btnupdate.Visible = false;
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(TBCID.Text);
            Course c = ob.search(id);
            if (c == null)
                MessageBox.Show("enter the valid CID as this doesnt exist");
            else
            {
                label2.Visible = true;
                label3.Visible = true;
                TBCNAME.Visible = true;
                TBCAT.Visible = true;
                btnupdate.Visible = true;
                btncheck.Visible = false;
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Course c = new Course();
            c.Cid = Convert.ToInt32(TBCID.Text);
            c.Cname = TBCNAME.Text.ToString();
            c.Category = TBCAT.Text.ToString();

            ob.updatesp(c);

            TBCID.Text = "";
            TBCNAME.Text = "";
            TBCAT.Text = "";

            dataGridView1.DataSource = ob.getAllData() ;

            label2.Visible = false;
            label3.Visible = false;
            TBCAT.Visible = false;
            TBCNAME.Visible = false;
            btnupdate.Visible = false;
            btncheck.Visible = true;

        }
    }
}
