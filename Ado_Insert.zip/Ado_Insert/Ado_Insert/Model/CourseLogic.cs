﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;


namespace Ado_Insert.Model
{
    class CourseLogic
    {
        private string conStr = ConfigurationManager.ConnectionStrings["coursedb"].ConnectionString;

        public List<Course> getAllData()
        {
            List<Course> li = new List<Course>();
            string sql = "select * from Course";
            SqlConnection conn = new SqlConnection(conStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                while(sqr.Read())
                {
                    Course ob = new Course();
                    ob.Cid = Convert.ToInt32(sqr.GetValue(0));
                    ob.Cname = sqr.GetValue(1).ToString();
                    ob.Category = sqr.GetValue(2).ToString();
                    li.Add(ob);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return li;
        }

        public string Add(Course c)
        {
            string msg=null;
            SqlConnection conn = new SqlConnection(conStr);

            string sql = "insert into Course values("+ c.Cid + ",'" + c.Cname +"','"+c.Category+"');";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);

                cmd.ExecuteNonQuery();
                msg = "Data inserted successfully";
            }
            catch(Exception)
            {
                msg = "Couldnt insert the data!!!";
            }
            finally
            {
                conn.Close();
            }
            return msg;
        }

        public string addsp(Course c)
        {
            string message = null;
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "spinsertcourse";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id",SqlDbType.Int).Value = c.Cid ;
                cmd.Parameters.Add("@cname", SqlDbType.VarChar, 50).Value = c.Cname;
                cmd.Parameters.Add("@category", SqlDbType.VarChar, 50).Value = c.Category;
                cmd.ExecuteNonQuery();                             
                message = "Data inserted successfully";
            }
            catch (Exception)
            {
                message = "Couldnt insert the data!!!";
            }
            finally
            {
                conn.Close();
            }
            return message;
        }


        public Course search(int id)
        {
            
            string sql = "select * from Course where cid="+id;
            SqlConnection conn = new SqlConnection(conStr);

            Course ob = new Course();

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader sqr = cmd.ExecuteReader();
                if(sqr.HasRows)
                {
                    while (sqr.Read())
                    {
                        ob.Cid = Convert.ToInt32(sqr.GetValue(0));
                        ob.Cname = sqr.GetValue(1).ToString();
                        ob.Category = sqr.GetValue(2).ToString();
                    }
                }
                else
                {
                    ob = null;
                }
                
            }
            catch (Exception)
            {
                MessageBox.Show("CANNOT CONNECT DATABASE");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }

        public void updatesp(Course c)
        {
            SqlConnection conn = new SqlConnection(conStr);
            string sql = "spupdate";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = c.Cid;
                cmd.Parameters.Add("@cname", SqlDbType.VarChar, 50).Value = c.Cname;
                cmd.Parameters.Add("@category", SqlDbType.VarChar, 50).Value = c.Category;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data updated successfully");
            }
            catch (Exception)
            {
                MessageBox.Show("Couldnt update the data!!!");
            }
            finally
            {
                conn.Close();
            }
        }
    }
}












