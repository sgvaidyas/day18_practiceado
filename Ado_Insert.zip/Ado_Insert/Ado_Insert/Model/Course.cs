﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ado_Insert.Model
{
    class Course
    {
        public int Cid { get; set; }
        public string Cname { get; set; }
        public string Category { get; set; }
    }
}
