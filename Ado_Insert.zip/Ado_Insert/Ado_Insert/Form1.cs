﻿using Ado_Insert.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_Insert
{
    public partial class Form1 : Form
    {
        CourseLogic ob;
        public Form1()
        {
            InitializeComponent();
            ob = new CourseLogic();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Course c = new Course();
            c.Cid = Convert.ToInt32(tbcid.Text);
            c.Cname = tbcname.Text.ToString();
            c.Category = tbcategory.Text.ToString();
            // string msg = ob.Add(c);
            string msg = ob.addsp(c);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getAllData();
            tbcid.Text = "";
            tbcname.Text = "";
            tbcategory.Text = "";

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
        }
    }
}
