﻿using Ado_Insert.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ado_Insert
{
    public partial class Form2 : Form
    {
        CourseLogic ob;

        public Form2()
        {
            InitializeComponent();
            ob = new CourseLogic();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {

            dataGridView1.Visible = false;
            int i;
            i = Convert.ToInt32(tbsearch.Text);
            Course c =  ob.search(i);
            if(c==null)
            {
                MessageBox.Show("the record is Not present");
            }
            else
            {
                dataGridView1.Visible = true;
                List<Course> li = new List<Course>();
                li.Add(c);
                dataGridView1.DataSource = li;
                MessageBox.Show("the record  is present");
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }
    }
}
