﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace PracticeProj.Model
{
    class CourseLogic
    {
        private string constr = ConfigurationManager.ConnectionStrings["Coursedb"].ConnectionString;

        public List<Course> getAllData()
        {
            List<Course> ob = new List<Course>();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Course";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    Course c = new Course();
                    c.Cid =  Convert.ToInt32(reader.GetValue(0));
                    c.Cname = reader.GetValue(1).ToString();
                    c.Category = reader.GetValue(2).ToString();
                    ob.Add(c);
                }
            }
            catch(Exception)
            {
                MessageBox.Show("Couldnt connect to db");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }


        public Course search( int id  )
        {
            Course ob= new Course();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Course where cid="+id;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ob.Cid = Convert.ToInt32(reader.GetValue(0));
                        ob.Cname = reader.GetValue(1).ToString();
                        ob.Category = reader.GetValue(2).ToString();
                    }
                }
                else
                    ob = null;                
            }
            catch (Exception)
            {
                MessageBox.Show("search not found");
            }
            finally
            {
                conn.Close();
            }
            return ob;
        }

        public void updatedata(Course c)
        {
            SqlConnection conn = new SqlConnection(constr);
            string sql = "sp_update";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@cid",SqlDbType.Int).Value = c.Cid;
                cmd.Parameters.Add("@cname", SqlDbType.VarChar, 50).Value = c.Cname;
                cmd.Parameters.Add("@cat", SqlDbType.VarChar, 50).Value = c.Category;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated the record");
            }
            catch(Exception)
            {
                MessageBox.Show("Cannot update!!!");
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
