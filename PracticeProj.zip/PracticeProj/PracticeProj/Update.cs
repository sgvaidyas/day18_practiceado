﻿using PracticeProj.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticeProj
{
    public partial class Update : Form
    {
        CourseLogic ob;
        public Update()
        {
            InitializeComponent();
            ob = new CourseLogic();
        }

        private void Update_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();

            label2.Visible = false;
            tbcname.Visible = false;
            label3.Visible = false;
            tbcategory.Visible = false;
            btnupdate.Visible = false;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Course c = new Course();
            c.Cid = Convert.ToInt32(tbid.Text);
            c.Cname = tbcname.Text.ToString();
            c.Category = tbcategory.Text.ToString();
            ob.updatedata(c);
            dataGridView1.DataSource = ob.getAllData();
        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(tbid.Text);
            Course c = ob.search(id);

            if(c==null)
            {
                MessageBox.Show("Enter the valid Course id as its not present");
            }
            else
            {
                label2.Visible = true;
                tbcname.Visible = true;
                label3.Visible = true;
                tbcategory.Visible = true;
                btnupdate.Visible = true;
                btncheck.Visible = false;

            }
        }
    }
}
