﻿using PracticeProj.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticeProj
{
    public partial class Search : Form
    {
        CourseLogic ob;
        public Search()
        {
            InitializeComponent();
            ob = new CourseLogic();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            int id = Convert.ToInt32(tbid.Text);
            Course c = ob.search(id);
            if (c == null)
                MessageBox.Show("NO data present");
            else
            {
                List<Course> li = new List<Course>();
                li.Add(c);
                
                MessageBox.Show("data is present");
                dataGridView1.Visible = true;
                dataGridView1.DataSource = li;
            }
            tbid.Text = "";

        }
    }
}
