﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App_adapter
{
    class Course
    {
        public int Cid { get; set; }
        public string Cname { get; set; }
        public string Ccategory { get; set; }
    }
}
