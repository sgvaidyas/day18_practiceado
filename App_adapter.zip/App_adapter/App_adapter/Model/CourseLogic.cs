﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace App_adapter.Model
{
    class CourseLogic
    {
        private string conString = ConfigurationManager.ConnectionStrings["coursedb"].ConnectionString;

        public DataSet GetAllCourseDetails()
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(conString);
            string sql = " select * from sys.tables ;select * from Student;select * from Course";

            try
            {
                conn.Open();
                SqlDataAdapter sqladapter = new SqlDataAdapter(sql,conn);
                sqladapter.Fill(ds);
            }
            catch(Exception)
            {
                MessageBox.Show("Database detected problems.....");
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
    }
}
