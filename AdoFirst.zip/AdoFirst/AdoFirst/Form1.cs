﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdoFirst.Model;

namespace AdoFirst
{
    public partial class Form1 : Form
    {

        StudntLogic stud = new StudntLogic();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
            dataGridView1.DataSource= stud.getAllStudents();

            dataGridView2.DataSource = stud.GetAllData().Tables[1];


            comboBox1.DataSource = stud.GetAllData().Tables[0];
            comboBox1.DisplayMember = "name";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = comboBox1.SelectedIndex;
            i++;
            dataGridView2.DataSource = stud.GetAllData().Tables[i];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            StudntLogic ob = new StudntLogic();
            Student st = new Student();
            st.Id =Convert.ToInt32( textBox1.Text);
            st.name = textBox2.Text;
            st.age = Convert.ToInt32(textBox3.Text);
            st.fees = float.Parse(textBox4.Text);
            //MessageBox.Show(ob.Add(st));
            MessageBox.Show(ob.Addsp(st));
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

            dataGridView1.DataSource = stud.getAllStudents();

            dataGridView2.DataSource = stud.GetAllData().Tables[1];
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            StudntLogic ob = new StudntLogic();
            label8.Text =ob.getScalar("select sum(fees) from Student");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            StudntLogic ob = new StudntLogic();
            int id = Convert.ToInt32(textBox5.Text);
            string msg = ob.Deltesp(id);
            MessageBox.Show(msg);
            textBox5.Text = "";
            dataGridView1.DataSource = stud.getAllStudents();

            dataGridView2.DataSource = stud.GetAllData().Tables[1];

        }
    }
}
