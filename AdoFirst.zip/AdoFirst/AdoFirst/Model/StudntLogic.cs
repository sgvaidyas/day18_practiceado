﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace AdoFirst.Model
{
    class StudntLogic
    {
        private string connectionString = ConfigurationManager.ConnectionStrings["db"].ConnectionString;

        public List<Student> getAllStudents()
        {
            List<Student> li = new List<Student>();
            //create connection
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                
                //query
                string sql = "select * from Student";
                //established connection opens
                conn.Open();
                //execute query
                SqlCommand cmd = new SqlCommand(sql, conn);
                //reads each record
                SqlDataReader reader = cmd.ExecuteReader();

                while(reader.Read())
                {
                    Student stu = new Student();
                    stu.Id =Convert.ToInt32(reader.GetValue(0));
                    stu.name = reader.GetValue(1).ToString();
                    stu.age = Convert.ToInt32(reader.GetValue(2));
                    stu.fees = float.Parse(reader.GetValue(3).ToString());
                    li.Add(stu);
                }
            }
            catch(Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            return li;
        }

        public DataSet GetAllData()
        {
            DataSet ds = new DataSet();
            //create connection
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                //query
                string sql = "select * from sys.tables;select * from Student;select * from Course;";
                //established connection opens
                conn.Open();
                SqlDataAdapter sqadapter = new SqlDataAdapter(sql,conn);
                sqadapter.Fill(ds);
            }
            catch (Exception)
            {

            }
            finally
            {
                conn.Close();
            }
            return ds;

        }

        public string Add(Student st)
        {
            string str = null;
            string sql = "insert into Student values(" + st.Id + ",'" + st.name + "'," + st.age + "," + st.fees + ")";
            MessageBox.Show(sql);
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql,conn);

                cmd.ExecuteNonQuery();
                str = "data inserted successfully ...........";
            }
            catch(Exception)
            {
                str = "Sorry couldnt insert ";
            }
            finally
            {
                conn.Close();
            }
            return str;
        }
        public string Addsp(Student st)
        {
            string str = null;
            string sql = "spInsertStudent";
            MessageBox.Show(sql);
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Id ", SqlDbType.Int).Value = st.Id;
                cmd.Parameters.Add("@name", SqlDbType.VarChar,50).Value = st.name;
                cmd.Parameters.Add("@age", SqlDbType.Int).Value = st.age;
                cmd.Parameters.Add("@fees", SqlDbType.Float).Value = st.fees;
                SqlParameter para = new SqlParameter();
                para.SqlDbType = SqlDbType.Int;
                para.Direction = ParameterDirection.Output;
                para.ParameterName = "@opid";
                cmd.Parameters.Add(para);

                cmd.ExecuteNonQuery();
                str = para.Value.ToString();
            }
            catch (Exception)
            {
                str = "Sorry couldnt insert ";
            }
            finally
            {
                conn.Close();
            }
            return str;
        }

        public string getScalar(string s)
        {
            string str = null;
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(s, conn);

                str = cmd.ExecuteScalar().ToString();
                
            }
            catch (Exception)
            {
                str = "Sorry couldnt insert ";
            }
            finally
            {
                conn.Close();
            }

            return str;
        }

        public string Deltesp(int id)
        {
            string str = null;
            string sql = "spDelete";
            
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id ", SqlDbType.Int).Value = id;
                
                cmd.ExecuteNonQuery();
                str = "DATA DELETED .....";
            }
            catch (Exception)
            {
                str = "Sorry couldnt DELETE ";
            }
            finally
            {
                conn.Close();
            }
            return str;
        }

    }
}
